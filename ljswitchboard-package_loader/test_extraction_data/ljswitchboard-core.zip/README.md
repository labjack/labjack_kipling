ljswitchboard-core
==================

The core node-webkit code for the ljswitchboard (Kipling) project
