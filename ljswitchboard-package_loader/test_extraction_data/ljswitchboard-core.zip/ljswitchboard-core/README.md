# ljswitchboard-static_files
A repository for all of ljswitchboard's static files that should be extracted very rarely and slow down the startup time a LOT.
